import express from "express";
import { createServer as createViteServer } from "vite";
import { Telegraf } from "telegraf";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { Octokit } from "octokit";
import cookieSession from "cookie-session";
import fs from "fs/promises";
import path from "path";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cookieSession({
  name: 'session',
  keys: [process.env.SESSION_SECRET || 'default-secret'],
  maxAge: 24 * 60 * 60 * 1000, // 24 hours
  secure: true,
  sameSite: 'none',
  httpOnly: true,
}));

// Lazy initialize Gemini
let genAI: GoogleGenAI | null = null;
function getGenAI() {
  if (!genAI) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    genAI = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return genAI;
}

const telegramToken = process.env.TELEGRAM_BOT_TOKEN || "8672160694:AAGIPtUCa8xcmLDewY6l9ErYzD5P4ISqpkQ";

async function startServer() {
  // --- Telegram Bot Logic ---
  if (telegramToken) {
    const bot = new Telegraf(telegramToken);

    bot.start((ctx) => {
      ctx.reply(
        "مرحباً بك! أنا بوت خبير في تحسين منشورات التواصل الاجتماعي. 🚀\n" +
        "أرسل لي أي نص، وسأقوم بإعادة صياغته ليكون جذاباً واحترافياً."
      );
    });

    bot.on("text", async (ctx) => {
      const userText = ctx.message.text;
      
      try {
        const ai = getGenAI();
        // For Telegram, we'll use a smart default prompt that covers all bases
        const prompt = `أنت خبير تسويق رقمي محترف. قم بتحسين المنشور التالي لمنصات التواصل الاجتماعي.
              النص الأصلي: "${userText}"
              
              المطلوب:
              1. كتابة "خطاف" (Hook) قوي وجذاب.
              2. إعادة صياغة النص بشكل تفاعلي ومقسم للنقاط.
              3. إضافة رموز تعبيرية (Emojis) مناسبة.
              4. إضافة 5 هاشتاجات قوية.
              5. الترجمة: قدم نسخة مترجمة للإنجليزية في نهاية المنشور.
              
              اجعل النبرة احترافية وجذابة.`;

        const model = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: [{ role: "user", parts: [{ text: prompt }] }]
        });

        await ctx.reply(model.text || "عذراً، لم أستطع معالجة النص.");
      } catch (error) {
        console.error("Telegram Bot Error:", error);
        await ctx.reply("عذراً، حدث خطأ أثناء الاتصال بالذكاء الاصطناعي.");
      }
    });

    bot.catch((err: any) => {
      if (err?.response?.error_code === 409 || err?.message?.includes('409')) {
        console.warn("⚠️ [Telegraf Conflict] Another instance of the bot is already running. This instance will standby.");
      } else {
        console.error("❌ Telegram Bot Error:", err);
      }
    });

    bot.launch()
      .then(() => {
        console.log("🤖 Telegram Bot successfully launched!");
      })
      .catch(err => {
        if (err?.response?.error_code === 409 || err?.message?.includes('409')) {
          console.warn("⚠️ [Telegraf Conflict 409] Another instance is running with the same token. This instance will standby.");
        } else {
          console.error("❌ Telegram Bot failed to launch:", err);
        }
      });

    // Graceful stop signals to release the bot handle on server reload/shutdown
    process.once('SIGINT', () => {
      try { bot.stop('SIGINT'); } catch(e) {}
    });
    process.once('SIGTERM', () => {
      try { bot.stop('SIGTERM'); } catch(e) {}
    });
  }

  // --- GitHub OAuth & Push Logic ---
  app.get('/api/auth/github/url', (req, res) => {
    const redirectUri = `${process.env.APP_URL || `https://${req.get('host')}`}/auth/github/callback`;
    const params = new URLSearchParams({
      client_id: process.env.GITHUB_CLIENT_ID!,
      redirect_uri: redirectUri,
      scope: 'repo,user',
    });
    res.json({ url: `https://github.com/login/oauth/authorize?${params}` });
  });

  app.get('/auth/github/callback', async (req, res) => {
    const { code } = req.query;
    try {
      const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({
          client_id: process.env.GITHUB_CLIENT_ID,
          client_secret: process.env.GITHUB_CLIENT_SECRET,
          code,
        }),
      });
      const data = await tokenResponse.json();
      if (data.access_token) {
        const session = (req as any).session;
        if (session) {
          session.githubToken = data.access_token;
        }
        res.send(`
          <html><body><script>
            window.opener.postMessage({ type: 'GITHUB_AUTH_SUCCESS' }, '*');
            window.close();
          </script></body></html>
        `);
      } else {
        res.status(400).send('Failed to get access token');
      }
    } catch (error) {
      res.status(500).send('Authentication error');
    }
  });

  app.get('/api/github/user', async (req, res) => {
    const token = (req as any).session?.githubToken;
    if (!token) return res.status(401).json({ error: 'Not authenticated' });
    const octokit = new Octokit({ auth: token });
    const { data } = await octokit.rest.users.getAuthenticated();
    res.json(data);
  });

  app.post('/api/github/push', async (req, res) => {
    const token = (req as any).session?.githubToken;
    if (!token) return res.status(401).json({ error: 'Not authenticated' });
    const { repoName } = req.body;
    const octokit = new Octokit({ auth: token });

    try {
      // 1. Create Repo
      const { data: repo } = await octokit.rest.repos.createForAuthenticatedUser({
        name: repoName || 'social-post-pro',
        auto_init: true,
      });

      // 2. Get all files
      const filesToPush = [
        'package.json', 'tsconfig.json', 'vite.config.ts', 'index.html', 'server.ts', 'metadata.json', '.env.example',
        'src/App.tsx', 'src/main.tsx', 'src/index.css'
      ];

      for (const filePath of filesToPush) {
        try {
          const content = await fs.readFile(path.join(process.cwd(), filePath), 'utf8');
          await octokit.rest.repos.createOrUpdateFileContents({
            owner: repo.owner.login,
            repo: repo.name,
            path: filePath,
            message: `Add ${filePath}`,
            content: Buffer.from(content).toString('base64'),
          });
        } catch (e) {
          console.warn(`Skipping ${filePath}:`, e);
        }
      }

      res.json({ success: true, url: repo.html_url });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Express & Vite Logic ---
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", bot_active: !!telegramToken });
  });

  // --- Post Improver API ---
  app.post("/api/improve", async (req, res) => {
    const { text, platform, tone, lang } = req.body;
    if (!text) {
      return res.status(400).json({ error: "النص الأصلي مطلوب" });
    }

    try {
      const ai = getGenAI();
      
      // Determine Platform, Tone and Translation parameters
      let platformDesc = "";
      switch (platform) {
        case "instagram":
          platformDesc = "إنستغرام (Instagram - ركز على الجذب البصري، خطاف مثير، والرموز التعبيرية والهاشتاجات ذات الصلة)";
          break;
        case "linkedin":
          platformDesc = "لينكد إن (LinkedIn - نبرة احترافية، بناء فكري، مقسم لنقاط واضحة لسهولة القراءة، مسافة كافية بين الفقرات، لا تبالغ في الهاشتاجات)";
          break;
        case "twitter":
          platformDesc = "إكس/تويتر (X/Twitter - موجز وقصير، مثير للاهتمام للتفاعل والمشاركة، مركز على فكرة أو فكرتين ومع ردم الهاشتاجات)";
          break;
        case "facebook":
          platformDesc = "فيسبوك (Facebook - تفاعلي، دافئ، مناسب للمجتمعات والمشاركات الطويلة، دعوة واضحة للتفاعل والمشاركة)";
          break;
        default:
          platformDesc = "أشكال متعددة لوسائل التواصل الاجتماعي المختلفة";
      }

      let toneDesc = "";
      switch (tone) {
        case "professional":
          toneDesc = "احترافي ومسؤول (Professional - لغة عمل راقية ومقنعة)";
          break;
        case "funny":
          toneDesc = "مرح وساخر خفيف (Funny - لطيف وفيه فكاهة جذابة تسعد المتابعين)";
          break;
        case "inspiring":
          toneDesc = "ملهم وحماسي (Inspiring - يحمس القارئ ويدفعه للعمل والتفاؤل)";
          break;
        case "formal":
          toneDesc = "رسمي ومفصل (Formal - لغة فصيحة، موضوعية وبدون تكلف)";
          break;
        case "marketing":
          toneDesc = "تسويقي ومقنع (Marketing - يدفع للشراء أو اتخاذ إجراء مباشر، يبرز الميزات والحلول)";
          break;
        default:
          toneDesc = "تفاعلي جذاب";
      }

      let langDesc = "";
      if (lang === "en") {
        langDesc = "قم بصياغة المنشور باللغة الإنجليزية بالكامل بدقة واحترافية تسويقية عالية.";
      } else if (lang === "fr") {
        langDesc = "قم بصياغة المنشور باللغة الفرنسية بالكامل بدقة واحترافية تسويقية عالية.";
      } else if (lang === "ar_en") {
        langDesc = "قم بصياغة المنشور باللغة العربية أولاً، ثم ألحقها بترجمة إنجليزية احترافية بالكامل في القسم السفلي.";
      } else {
        langDesc = "حافظ على اللغة العربية كلغة أساسية واجعل الصياغة فصيحة ومناسبة لجمهور عربي.";
      }

      const prompt = `أنت خبير تسويق رقمي فذ وصانع محتوى محترف. 
مهمتك هي تحسين وإعادة صياغة المنشور التالي لمنصات التواصل الاجتماعي ليصبح فائق الجاذبية والانتشار.

النص الأصلي للمنشور:
"${text}"

المعايير المحددة للتعديل:
1. المنصة المستهدفة: ${platformDesc}
2. نبرة الصوت: ${toneDesc}
3. اللغة والترجمة: ${langDesc}

إرشادات الصياغة الإبداعية:
- اكتب خطافاً (Hook) افتتاحياً رائعاً وخاطفاً للأبصار لجعل القارئ يضغط على زر 'قراءة المزيد'.
- قسّم النص إلى جمل مريحة للعين واستخدم النقاط (Bullet points) لتسهيل الفهم والمسح البصري.
- أضف رموزاً تعبيرية (Emojis) منسجمة ومعبرة لتضيف حيوية للمنشور.
- اختم المنشور دائماً بدعوة صريحة للتفاعل (CTA - Call To Action) تناسب المنصة والهدف المحفز.
- أضف 5-8 هاشتاجات ذات صلة قوية وعصرية تناسب المنصة وموضوع المقطع في النهاية.
- نبرة الرد يجب أن تكون فورية ومقنعة، لا تكتب مقدمة مثل "هنا منشورك المعدل"، ابدأ بكتابة المنشور مباشرة ليكون جاهزاً للنسخ والاستخدام.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: {
          systemInstruction: "أنت كاتب محتوى ومسوق رقمي خبير بلغات التواصل واللغات الإبداعية المتعددة.",
        }
      });

      const improvedText = response.text || "عذراً، لم أتمكن من تحسين هذا المنشور.";
      res.json({ improvedText });
    } catch (error: any) {
      console.error("Gemini API error:", error);
      res.status(500).json({ error: error.message || "حدث خطأ غير متوقع أثناء معالجة طلبك" });
    }
  });

  app.post("/api/generate-image", async (req, res) => {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: "نص المنشور مطلوب لتوليد صورة" });
    }

    try {
      const ai = getGenAI();
      const prompt = `صمم غلاف أو صورة تسويقية معبرة وملهمة جداً لمنصات التواصل الاجتماعي تعكس تماماً موضوع المنشور التالي، بدون إضافة أي نصوص لغوية على التصميم لتكون الصورة نظيفة تماماً وعالية الجودة والفن البصري المعاصر:
"${text}"`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: {
          imageConfig: {
            aspectRatio: "1:1",
          }
        }
      });

      let imageUrl = "";
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64EncodeString = part.inlineData.data;
            imageUrl = `data:image/png;base64,${base64EncodeString}`;
            break;
          }
        }
      }

      if (imageUrl) {
        res.json({ imageUrl });
      } else {
        res.status(500).json({ error: "لم يتم العثور على صورة منتجة من النموذج" });
      }
    } catch (error: any) {
      console.error("Image generation failed:", error);
      // Fallback design
      try {
        const fallbackUrl = `https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80`;
        res.json({ imageUrl: fallbackUrl, warning: "تم استخدام صورة تعبيرية مبدعة بسبب قيود حصة توليد الصور" });
      } catch (e) {
        res.status(500).json({ error: error.message || "فشل توليد الصورة الفنية" });
      }
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 Web Server running on http://localhost:${PORT}`);
  });
}

startServer();
