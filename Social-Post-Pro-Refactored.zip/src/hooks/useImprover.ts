import { useState } from 'react';

export type Platform = 'instagram' | 'linkedin' | 'twitter' | 'facebook';
export type Tone = 'professional' | 'funny' | 'inspiring' | 'formal' | 'marketing';
export type Lang = 'ar' | 'en' | 'fr' | 'ar_en';

export const useImprover = () => {
  const [platform, setPlatform] = useState<Platform>('instagram');
  const [tone, setTone] = useState<Tone>('professional');
  const [lang, setLang] = useState<Lang>('ar');
  const [inputText, setInputText] = useState('');
  const [improvedText, setImprovedText] = useState('');
  const [generatedImage, setGeneratedImage] = useState('');
  const [isImproving, setIsImproving] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [errorLocal, setErrorLocal] = useState('');
  const [warningMessage, setWarningMessage] = useState('');

  const handleImprovePost = async () => {
    if (!inputText.trim()) return;
    setIsImproving(true);
    setErrorLocal('');
    setWarningMessage('');
    setImprovedText('');
    setGeneratedImage('');

    try {
      const res = await fetch("/api/improve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: inputText, platform, tone, lang }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "فشل تحسين المنشور.");
      }
      setImprovedText(data.improvedText);
    } catch (err: any) {
      console.error(err);
      setErrorLocal(err.message || "حدث خطأ أثناء رصد التحسينات بالذكاء الاصطناعي.");
    } finally {
      setIsImproving(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!improvedText) return;
    setIsGeneratingImage(true);
    setErrorLocal('');
    setWarningMessage('');

    try {
      const res = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: improvedText }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "فشل توليد الصورة الفنية.");
      }
      setGeneratedImage(data.imageUrl);
      if (data.warning) {
        setWarningMessage(data.warning);
      }
    } catch (err: any) {
      console.error(err);
      setErrorLocal(err.message || "عذراً، فشل توليد الصورة الفنية بالذكاء الاصطناعي.");
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleCopyText = () => {
    if (!improvedText) return;
    navigator.clipboard.writeText(improvedText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return {
    platform, setPlatform,
    tone, setTone,
    lang, setLang,
    inputText, setInputText,
    improvedText, setImprovedText,
    generatedImage, setGeneratedImage,
    isImproving,
    isGeneratingImage,
    isCopied,
    errorLocal, setErrorLocal,
    warningMessage,
    handleImprovePost,
    handleGenerateImage,
    handleCopyText
  };
};
